package com.scalessec.dialogs;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DialogsActivity extends Activity {
	
	static final int COLOR_DIALOG_ID = 0;
	static final int ALERT_DIALOG_ID = 1;
	
	static String selectedColor = "Black";
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        final Button buttonColor = (Button)findViewById(R.id.buttonColor);
        final Button buttonAlert = (Button)findViewById(R.id.buttonAlert);

		buttonColor.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				showDialog(COLOR_DIALOG_ID);
			}
		});
		
		buttonAlert.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				showDialog(ALERT_DIALOG_ID);
			}
		});
	
    }
    
    @Override
	protected Dialog onCreateDialog(int id, Bundle bundle) {
		final TextView textView = (TextView)findViewById(R.id.textView);
		final String[] colorNames = {"Red", "Yellow", "Green", "Cyan", "Blue", "Magenta", "Gray", "Black"};
		final int[] colorValues = {Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.GRAY, Color.BLACK};

		switch (id) {
			case COLOR_DIALOG_ID:
				AlertDialog.Builder builderColor = new AlertDialog.Builder(this);
				builderColor.setTitle("Pick a color:");
				
				builderColor.setItems(colorNames, new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int index) {
						selectedColor = colorNames[index];
						textView.setText("You selected: " + selectedColor + ".");
						
				        View root = textView.getRootView();
				        root.setBackgroundColor(colorValues[index]);
					}
				});
				
				return builderColor.create();
			
			case ALERT_DIALOG_ID:
				AlertDialog.Builder builderAlert = new AlertDialog.Builder(this);
				//builderAlert.setTitle("Do you want to know what I think?");
				builderAlert.setMessage("I think " + selectedColor.toLowerCase() + " is a wonderful color. Don't you?");
				
				builderAlert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						Log.d("ALERT", "Affirmative.");
					}
				});
				
				builderAlert.setNegativeButton("No, not really.", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						Log.d("ALERT", "Negative.");
					}
				});
				
				AlertDialog alertDialog = builderAlert.create();
				return alertDialog;
				
			default:
				return null;
		}
	}

    
}